
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include <string.h>

#include "zzFaceDLL.h"
#include "mxImageTool.h"

int FileSize(const char* szFileName)
{
	long size = 0;
	FILE *fp;
	fp = fopen(szFileName,"rb");
	if(!fp)
		return 0;
	fseek(fp,0,SEEK_END);
	size = ftell(fp);
	fclose(fp);
	return size;
}

int GetFileData(const char* szFileName,unsigned char *buf,int length)
{
	FILE *fp;
	fp = fopen(szFileName,"rb");
	if(!fp)
		return 0;
	fread(buf,1,length,fp);
	fclose(fp);
	return 1;
}

int SaveFileData(const char* szFileName,unsigned char *buf,int length)
{
	FILE *fp;
    if(length<=0)
        return -1;
	fp = fopen(szFileName,"wb");
	if(!fp)
		return 0;
	fwrite(buf,1,length,fp);
	fclose(fp);
	return 1;
}

int ReadData(char *szFileName, unsigned char *oBuf, int iLen)
{
	FILE *fp;
	fp = fopen(szFileName, "rb");
	if (!fp)
	{
		return -1;
	}
	fread(oBuf, 1, iLen, fp);
	fclose(fp);
	return 0;
}

int SaveData(char* file, unsigned char* pTemp, int TempLen)
{
	FILE *fp;
	fp = fopen(file, "wb");
	if (fp == NULL) return 0;
	fwrite(pTemp, TempLen * sizeof(unsigned char), 1, fp);
	fclose(fp);
	return 1;
}


int GetTz(void* pAlgEngine,char* szFilename,int iIndex)
{
	double fRunTimeFaceDetect  = 0;
	double fRunTimeFeature    = {0};
	unsigned char *pFileBuff   = NULL;
	unsigned char *pRGBBuff    = NULL;
	int nRet = -1;
	int oX = 0;
	int oY = 0;
	int pfilesize = 0;
	int iFileLength = FileSize(szFilename);
	if (iFileLength <=0)
	{
		printf("读取图像失败\r\n");
		return -1;
	}
	pFileBuff = (unsigned char *)malloc(iFileLength);
	GetFileData(szFilename,pFileBuff,iFileLength);

	nRet = ImageDecode(pFileBuff, iFileLength,NULL, &oX, &oY);
	if (nRet < 0)
	{
		printf("图像格式解码失败\r\n");
		return -2;
	}
	pRGBBuff = (unsigned char *)malloc(oX*oY * 3);
	memset(pRGBBuff, 0x00, oX*oY * 3);
	nRet = ImageDecode(pFileBuff, iFileLength,pRGBBuff, &oX, &oY);
	if (nRet < 0)
	{
		printf("图像格式解码失败\r\n");
		return -3;
	}
	
	int iFaceNum = 0;
	MXFaceInfoEx *pFaceInfo = (MXFaceInfoEx *)malloc(100 * sizeof(MXFaceInfoEx));
	CVTimeStart();
	nRet = zzDetectFaceThread(pAlgEngine,pRGBBuff, oX, oY, &iFaceNum, pFaceInfo);
	fRunTimeFaceDetect = CVTimeRun();
	if (nRet != 0)
	{
		printf("zzDetectFaceThread failed: nRet=%d\n", nRet);
		return nRet;
	}
	
	//提取特征
	int iFeatureSize = zzGetFeatureSizeThread(pAlgEngine);
	unsigned char *pFeatureBuf = (unsigned char*)malloc(iFeatureSize*iFaceNum);
	memset(pFeatureBuf, 0x00, iFeatureSize*iFaceNum);
	CVTimeStart();
	zzExtractFeatureThread(pAlgEngine, pRGBBuff, oX, oY, iFaceNum, pFaceInfo, pFeatureBuf);
	fRunTimeFeature = CVTimeRun();
	
	//保存特征
	char szTzFile[256] = { 0 };
	sprintf(szTzFile, "./tz_%d.dat", iIndex);
	SaveFileData(szTzFile, pFeatureBuf, iFeatureSize*iFaceNum);
	for(int i=0;i<iFaceNum;i++)
	{
		int iRect[4] = { 0 };
		iRect[0] = pFaceInfo[i].x;
		iRect[1] = pFaceInfo[i].y;
		iRect[2] = pFaceInfo[i].width;
		iRect[3] = pFaceInfo[i].height;
		ImageDrawRect(pRGBBuff, oX, oY, iRect);

		int iPointPos[10] = { 0 };
		iPointPos[0] = pFaceInfo[i].keypt_x[0];
		iPointPos[1] = pFaceInfo[i].keypt_y[0];
		iPointPos[2] = pFaceInfo[i].keypt_x[1];
		iPointPos[3] = pFaceInfo[i].keypt_y[1];
		iPointPos[4] = pFaceInfo[i].keypt_x[2];
		iPointPos[5] = pFaceInfo[i].keypt_y[2];
		iPointPos[6] = pFaceInfo[i].keypt_x[3];
		iPointPos[7] = pFaceInfo[i].keypt_y[3];
		iPointPos[8] = pFaceInfo[i].keypt_x[4];
		iPointPos[9] = pFaceInfo[i].keypt_y[4];
		ImageDrawPoint(pRGBBuff, oX, oY, iPointPos, 5);
	}
	char szResultFile[256] = { 0 };
	sprintf(szResultFile, "./tz_%d.jpg", iIndex);
	ImageSave(szResultFile,pRGBBuff, oX, oY, 3);
	free(pFaceInfo);
	free(pFeatureBuf);
	free(pRGBBuff);
	free(pFileBuff);
	
	sprintf(szResultFile,"Success\r\nFace Num:%d\r\nDetectFace Time:%0.2fms\r\nExtractFeature Time:%0.2fms\r\n===================\r\n",
		iFaceNum,fRunTimeFaceDetect,fRunTimeFeature);
	printf(szResultFile);
	return 0;
}

int match(void* pAlgEngine)
{
	// TODO: 在此添加控件通知处理程序代码
	int iFeatureSize = zzGetFeatureSizeThread(pAlgEngine);
	unsigned char *pFeatureBuf1 =  NULL;
	unsigned char *pFeatureBuf2 =  NULL;
	char szFileName[256] = {0};
	int nRet = 0;
	sprintf(szFileName,"./tz_1.dat");
	int iSize = FileSize(szFileName);
	if (iSize<iFeatureSize)
	{
		if (pFeatureBuf1!=NULL)
		{
			free(pFeatureBuf1);
			pFeatureBuf1 = NULL;
		}
		if (pFeatureBuf2!=NULL)
		{
			free(pFeatureBuf2);
			pFeatureBuf2 = NULL;
		}
		printf("读取特征1失败");
		return -1;
	}
	int iFeatureNum1 = iSize/iFeatureSize;
	pFeatureBuf1 = (unsigned char*)malloc(iSize);
	GetFileData(szFileName,pFeatureBuf1,iSize);

	sprintf(szFileName,"./tz_2.dat");
	iSize = FileSize(szFileName);
	if (iSize<iFeatureSize)
	{
		if (pFeatureBuf1!=NULL)
		{
			free(pFeatureBuf1);
			pFeatureBuf1 = NULL;
		}
		if (pFeatureBuf2!=NULL)
		{
			free(pFeatureBuf2);
			pFeatureBuf2 = NULL;
		}
		printf("读取特征2失败");
		return -2; 
	}
	int iFeatureNum2 = iSize/iFeatureSize;
	pFeatureBuf2 = (unsigned char*)malloc(iSize);
	GetFileData(szFileName,pFeatureBuf2,iSize);

	float fScore = 0;
	float fMaxScore = 0;
	unsigned char * pFeatureBufTmp1 = (unsigned char*)malloc(iFeatureSize);
	unsigned char * pFeatureBufTmp2 = (unsigned char*)malloc(iFeatureSize);
	CVTimeStart();
	for (int i=0;i<iFeatureNum1;i++)
	{
		memcpy(pFeatureBufTmp1,pFeatureBuf1+i*iFeatureSize,iFeatureSize);
		for(int j=0;j<iFeatureNum2;j++)
		{
			memcpy(pFeatureBufTmp2,pFeatureBuf2+j*iFeatureSize,iFeatureSize);
			nRet = zzMatchFeatureThread(pAlgEngine, pFeatureBufTmp1, pFeatureBufTmp2, &fScore);
			if (nRet == 0)
			{
				if(fMaxScore<fScore)
				{
					fMaxScore = fScore;
				}
			}
		}
	}
	double fRunTimeMatch = CVTimeRun();
	free(pFeatureBufTmp1);
	free(pFeatureBufTmp2);

	if (pFeatureBuf1!=NULL)
	{
		free(pFeatureBuf1);
		pFeatureBuf1 = NULL;
	}
	if (pFeatureBuf2!=NULL)
	{
		free(pFeatureBuf2);
		pFeatureBuf2 = NULL;
	}
	char szResultFile[256]={0};
	sprintf(szResultFile,"Match Score:%.02f\r\nMatch Time:%0.2fms\r\n",fMaxScore,fRunTimeMatch);
	printf(szResultFile);
	return 0;	
}

void auth()
{
	char *szUserId = "";
	char *szPwd = "";
	char *szIP = "183.129.171.153";
	int  nPort = 1902;
	char szAuthInfo[1080 + 1] = { 0 };
	int  iAuthInfoLen = 0;
	char szErrInfo[256] = { 0 };
	if (strlen(szUserId)<2 || strlen(szPwd)<2)
	{
		printf("!!! please contact miaxis to obtain userID and key for authorization\n");
		return;
	}

	printf("IP=%s\r\n", szIP);
	printf("Port=%d\r\n", nPort);
	printf("UserId=%s\r\n", szUserId);
	printf("PWD=%s\r\n", szPwd);
	printf("==========================\r\n");
	int nRet = zzGetLienceData(szIP, nPort, szUserId, szPwd, 1002,szAuthInfo, &iAuthInfoLen, szErrInfo);
	if (nRet == 0)
	{
		SaveData("mxFaceSearchAPILicense.dat", (unsigned char *)szAuthInfo, iAuthInfoLen);
		printf("zzGetLienceData success,save to mxFaceSearchAPILicense.dat\r\n");
	}
	else
	{
		printf("zzGetLienceData error,nRet=%d,ErrInfo=%s\r\n", nRet, szErrInfo);
	}
}


int main()
{
#if defined(__linux__)
	printf("It is in Linux OS!\r\n");
#endif
    auth();
	char szVersion[256]={0};
	zzGetAlgVersionThread(szVersion);
	printf("%s\r\n",szVersion);
	
	void* pAlgEngine;
	int nRet = 0;
	pAlgEngine = zzInitAlgNThread("./",15000,&nRet);
	if (pAlgEngine == 0)
	{
		printf("zzInitAlgNThread failed: nRet=%d\n", nRet);
		return nRet;
	}
	nRet = GetTz(pAlgEngine,"./12.jpg",1);
	if (nRet != 0)
	{
		printf("GetTz failed: nRet=%d\n", nRet);
		return nRet;
	}	
	nRet = GetTz(pAlgEngine,"./2.jpg",2);
	if (nRet != 0)
	{
		printf("GetTz failed: nRet=%d\n", nRet);
		return nRet;
	}	
	match(pAlgEngine);
	
	zzFreeAlgThread(pAlgEngine);
	
	return 0;

}

